#include "Process.h"

#include "ScanFiles.h"
#include "FilterAudioFiles.h"
#include "RemovePrefixZeros.h"
#include "ConvertToM4a.h"

void processm4a(
    const std::string& inputFolder,
    const std::string& folderPath)
{
    scanFiles(inputFolder, folderPath);

    filterAudioFiles(folderPath);

    removePrefixZeros(folderPath);

    convertToM4a(folderPath);
}