#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "Process.h"
#include <QFileDialog>
#include <QIcon>
#include <QMessageBox>
#include <Qtime>
#include <QApplication>
#include <QFileDialog>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle("提取音频工具");
    setStyleSheet(
        "QMainWindow {"
        "background:qlineargradient("
        "x1:0,y1:0,"
        "x2:1,y2:1,"
        "stop:0 #f6f8fa,"
        "stop:1 #dfe9f3"
        ");"
        "}"
        );
    setWindowIcon(QIcon("3E41E955453448BD2EF3F39DE88DECD1.ico"));
}

MainWindow::~MainWindow()
{
    delete ui;
}
//
void MainWindow::on_pushButton_clicked()
{
    ui->textEdit->setReadOnly(true);
    QString inputFolder = ui->lineEdit->text();
    QString folderPath = ui->lineEdit_2->text();

    if (inputFolder.isEmpty() || folderPath.isEmpty())
        return;

    ui->textEdit->append(
        QTime::currentTime().toString("[hh:mm:ss] ")
        + "开始处理");
    processm4a(
        inputFolder.toStdString(),
        folderPath.toStdString());
    ui->textEdit->append(
        QTime::currentTime().toString("[hh:mm:ss] ")
        + "全部任务完成");
    ui->textEdit->ensureCursorVisible();
    QMessageBox::information(this,"完成","全部任务完成");
}


void MainWindow::on_pushButton_4_clicked()
{
     QApplication::quit();
}


void MainWindow::on_pushButton_2_clicked()
{
    QString path = QFileDialog::getExistingDirectory(
        this,
        "选择输入目录"
        );

    if (!path.isEmpty())
    {
        ui->lineEdit->setText(path);
    }
}


void MainWindow::on_pushButton_3_clicked()
{
    QString path = QFileDialog::getExistingDirectory(
        this,
        "选择输出目录"
        );

    if (!path.isEmpty())
    {
        ui->lineEdit_2->setText(path);
    }
}

