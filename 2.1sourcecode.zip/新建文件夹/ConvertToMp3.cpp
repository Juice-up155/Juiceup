#include "ConvertToMp3.h"

#include <filesystem>

#include <QProcess>
#include <QCoreApplication>
#include <QStringList>

namespace fs = std::filesystem;

void convertToMp3(const std::string& folderPath)
{
    if (!fs::exists(folderPath))
        return;

    // 获取程序所在目录下的 ffmpeg.exe
    QString ffmpegPath =
        QCoreApplication::applicationDirPath()
        + "/ffmpeg.exe";

    for (const auto& entry : fs::directory_iterator(folderPath))
    {
        if (!entry.is_regular_file())
            continue;

        fs::path inputPath = entry.path();

        // 跳过已经生成的 mp3
        if (inputPath.extension() == ".mp3")
            continue;

        fs::path outputPath =
            inputPath.parent_path() /
            (inputPath.stem().string() + ".mp3");

        QProcess process;

        process.start(
            ffmpegPath,
            QStringList()
                << "-y"
                << "-i"
                << QString::fromLocal8Bit(inputPath.string().c_str())
                << QString::fromLocal8Bit(outputPath.string().c_str())
            );

        process.waitForFinished(-1);

        if (process.exitStatus() == QProcess::NormalExit &&
            process.exitCode() == 0)
        {
            fs::remove(inputPath);
        }
    }
}