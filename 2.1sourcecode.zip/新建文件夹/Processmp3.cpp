#include "Process.h"

#include "ScanFiles.h"
#include "FilterAudioFiles.h"
#include "RemovePrefixZeros.h"
#include "ConvertToMp3.h"

void processmp3(
    const std::string& inputFolder,
    const std::string& folderPath)
{
    scanFiles(inputFolder, folderPath);

    filterAudioFiles(folderPath);

    removePrefixZeros(folderPath);

    convertToMp3(folderPath);
}