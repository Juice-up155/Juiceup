#ifndef CONVERTTOMP3_H
#define CONVERTTOMP3_H

#include <string>

void convertToMp3(const std::string& folderPath);

#endif