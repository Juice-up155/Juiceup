#pragma once

#include <string>

void filterAudioFiles(const std::string& folderPath);