 #pragma once

#include <string>
#include <vector>

std::vector<std::string> scanFiles(
    const std::string& inputFolder,
    const std::string& folderPath
);