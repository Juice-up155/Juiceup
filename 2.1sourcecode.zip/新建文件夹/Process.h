#ifndef PROCESS_H
#define PROCESS_H

#include <string>

void processm4a(
    const std::string& inputFolder,
    const std::string& folderPath);
void processmp3(
    const std::string& inputFolder,
    const std::string& folderPath);

#endif