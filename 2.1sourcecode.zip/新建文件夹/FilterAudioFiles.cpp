#include "FilterAudioFiles.h"

#include <filesystem>
#include <fstream>
#include <vector>
 
namespace fs = std::filesystem;

void filterAudioFiles(const std::string& folderPath)
{
    constexpr std::size_t READ_SIZE = 1 * 1024; 

    if (!fs::exists(folderPath))
    {
        return;
    }

    for (const auto& entry : fs::directory_iterator(folderPath))
    {
        if (!entry.is_regular_file())
        {
            continue;
        }

        std::ifstream file(entry.path(), std::ios::binary);

        if (!file)
        {
            continue;
        }

        std::vector<char> buffer(READ_SIZE);

        file.read(buffer.data(), READ_SIZE);

        std::size_t bytesRead = file.gcount();

        std::string content(buffer.data(), bytesRead);
 
        bool isAudio =
            content.find("soun") != std::string::npos;
 
     file.close();
        if (!isAudio)
        {
            fs::remove(entry.path());
        }
    }
}

 