#include "RemovePrefixZeros.h"

#include <filesystem>
#include <fstream>
#include <vector>

namespace fs = std::filesystem;

void removePrefixZeros(const std::string& folderPath)
{
    if (!fs::exists(folderPath))
        return;

    const std::vector<unsigned char> targetPrefix =
    {
        0x30, 0x30, 0x30,
        0x30, 0x30, 0x30,
        0x30, 0x30, 0x30
    };

    for (const auto& entry : fs::recursive_directory_iterator(folderPath))
    {
        if (!entry.is_regular_file())
            continue;

        const auto& filePath = entry.path();

        std::ifstream inFile(filePath, std::ios::binary);

        if (!inFile)
            continue;

        std::vector<unsigned char> fileData(
            (std::istreambuf_iterator<char>(inFile)),
            std::istreambuf_iterator<char>());

        inFile.close();

        if (fileData.size() < targetPrefix.size())
            continue;

        bool match = true;

        for (size_t i = 0; i < targetPrefix.size(); ++i)
        {
            if (fileData[i] != targetPrefix[i])
            {
                match = false;
                break;
            }
        }

        if (!match)
            continue;

        std::vector<unsigned char> newData(
            fileData.begin() + targetPrefix.size(),
            fileData.end());

        std::ofstream outFile(
            filePath,
            std::ios::binary | std::ios::trunc);

        if (!outFile)
            continue;

        outFile.write(
            reinterpret_cast<const char*>(newData.data()),
            static_cast<std::streamsize>(newData.size()));

        outFile.close();
    }
}
 
 