 #ifndef CONVERTTOM4A_H
#define CONVERTTOM4A_H

#include <string>

void convertToM4a(const std::string& folderPath);

#endif