 #include "ScanFiles.h"

#include <filesystem>

namespace fs = std::filesystem;

std::vector<std::string> scanFiles(
    const std::string& inputFolder,
    const std::string& folderPath)
{
    std::vector<std::string> copiedFiles;

    if (!fs::exists(inputFolder))
        return copiedFiles;

    if (!fs::exists(folderPath))
        return copiedFiles;

    for (const auto& entry :
         fs::recursive_directory_iterator(inputFolder))
    {
        if (!entry.is_regular_file())
            continue;

        if (entry.path().extension() != ".m4s")
            continue;

        try
        {
            fs::path sourcePath = entry.path();

            fs::path targetPath =
                fs::path(folderPath) /
                sourcePath.filename();

            if (fs::exists(targetPath))
            {
                std::string stem =
                    targetPath.stem().string();

                std::string extension =
                    targetPath.extension().string();

                int index = 1;

                do
                {
                    targetPath =
                        fs::path(folderPath) /
                        (stem + "_" +
                         std::to_string(index) +
                         extension);

                    ++index;

                } while (fs::exists(targetPath));
            }

            fs::copy_file(
                sourcePath,
                targetPath
            );

            copiedFiles.push_back(
                targetPath.string()
            );
        }
        catch (...)
        {
            continue;
        }
    }

    return copiedFiles;
}

 