#include "ConvertToM4a.h"

#include <filesystem>

#include <QProcess>
#include <QCoreApplication>
#include <QStringList>
#include <QDir>

namespace fs = std::filesystem;

void convertToM4a(const std::string& folderPath)
{
    if (!fs::exists(folderPath))
        return;

    QString ffmpegPath =
        QDir(QCoreApplication::applicationDirPath())
            .filePath("ffmpeg/ffmpeg.exe");

    for (const auto& entry : fs::directory_iterator(folderPath))
    {
        if (!entry.is_regular_file())
            continue;

        fs::path inputPath = entry.path();

        // 跳过已经生成的 m4a
        if (inputPath.extension() == ".m4a")
            continue;

        fs::path outputPath =
            inputPath.parent_path() /
            (inputPath.stem().string() + ".m4a");

        QProcess process;

        QString inputFile =
            QString::fromStdWString(inputPath.wstring());

        QString outputFile =
            QString::fromStdWString(outputPath.wstring());

        QStringList args;

        args << "-y"
             << "-i"
             << inputFile
             << "-c:a"
             << "copy"
             << "-f"
             << "mp4"
             << outputFile;

        process.start(ffmpegPath, args);

        process.waitForFinished(-1);

        if (process.exitStatus() == QProcess::NormalExit &&
            process.exitCode() == 0)
        {
            fs::remove(inputPath);
        }
    }
}