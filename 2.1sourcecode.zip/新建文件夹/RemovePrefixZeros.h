#pragma once

#include <string>

void removePrefixZeros(const std::string& folderPath);