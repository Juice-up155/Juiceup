#pragma once
#include <string>

int removeVideo(const std::wstring& targetPath);