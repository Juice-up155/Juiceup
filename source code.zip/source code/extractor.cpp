 #include "extractor.h"

#include <filesystem>
#include <iostream>

namespace fs = std::filesystem;

static fs::path get_unique_path(const fs::path& dest_dir,
                                const fs::path& filename)
{
    fs::path dest_path = dest_dir / filename;
    int count = 1;

    while (fs::exists(dest_path))
    {
        std::wstring stem = filename.stem().wstring();
        std::wstring ext  = filename.extension().wstring();

        std::wstring new_name =
            stem + L"(" + std::to_wstring(count) + L")" + ext;

        dest_path = dest_dir / new_name;
        count++;
    }

    return dest_path;
}

int extractM4s(const std::wstring& src_dir,
               const std::wstring& dest_dir)
{
    int count = 0;

    fs::create_directories(dest_dir);

    for (const auto& file : fs::recursive_directory_iterator(src_dir))
    {
        if (!file.is_regular_file()) continue;
        if (file.path().extension() != L".m4s") continue;

        fs::path dest_path =
            get_unique_path(dest_dir, file.path().filename());

        fs::copy_file(file.path(), dest_path);
        count++;
    }

    return count;
}