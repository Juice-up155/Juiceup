#include "videofilter.h"

#include <filesystem>
#include <iostream>

namespace fs = std::filesystem;

static bool isVideoFile(const fs::path& file)
{
    std::wstring name = file.filename().wstring();
    return name.find(L"video") != std::wstring::npos;
}

int removeVideo(const std::wstring& targetPath)
{
    int delNum = 0;

    for (auto& file : fs::directory_iterator(targetPath))
    {
        if (!file.is_regular_file()) continue;
        if (file.path().extension() != L".m4s") continue;

        if (isVideoFile(file.path()))
        {
            fs::remove(file.path());
            delNum++;
        }
    }

    return delNum;
}