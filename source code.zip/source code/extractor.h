#pragma once
#include <string>

int extractM4s(const std::wstring& src_dir,
               const std::wstring& dest_dir);