#include "converter.h"

#include <filesystem>

namespace fs = std::filesystem;

int convertToAac(const std::wstring& targetPath)
{
    int count = 0;

    for (auto& file : fs::directory_iterator(targetPath))
    {
        if (!file.is_regular_file()) continue;
        if (file.path().extension() != L".m4s") continue;

        fs::path newPath = file.path();
        newPath.replace_extension(L".aac");

        fs::rename(file.path(), newPath);
        count++;
    }
    return count;
}
