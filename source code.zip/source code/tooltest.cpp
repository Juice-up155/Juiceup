#include<iostream>
#include<filesystem>
#include<windows.h>
using namespace std;
int main()
{

    return 0;
}