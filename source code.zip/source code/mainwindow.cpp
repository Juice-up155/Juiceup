#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "process.h"
#include <QFileDialog>
#include <QApplication>
#include <Qtime>
#include <filesystem>
#include "extractor.h"
#include "converter.h"
#include "videofilter.h"
#include <QMessageBox>
#include <QIcon>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle("提取音频工具");
    setStyleSheet(
        "QMainWindow {"
        "background:qlineargradient("
        "x1:0,y1:0,"
        "x2:1,y2:1,"
        "stop:0 #f6f8fa,"
        "stop:1 #dfe9f3"
        ");"
        "}"
        );
     setWindowIcon(QIcon("EA6CA4A0E0994156968BCCB3C7912896 (1).ico"));
}

MainWindow::~MainWindow()
{
    delete ui;
}



void MainWindow::on_pushButton_clicked()
{
    ui->textEdit->setReadOnly(true);
    QString srcPath = ui->lineEdit->text();
    QString outPath = ui->lineEdit_2->text();

    if (srcPath.isEmpty() || outPath.isEmpty())
        return;

    ui->textEdit->append(
        QTime::currentTime().toString("[hh:mm:ss] ")
        + "开始处理");

    int total = extractM4s(
        srcPath.toStdWString(),
        outPath.toStdWString());

    ui->textEdit->append(
        QTime::currentTime().toString("[hh:mm:ss] ")
        + QString("提取文件 %1 个").arg(total));

    int video = removeVideo(
        outPath.toStdWString());

    ui->textEdit->append(
        QTime::currentTime().toString("[hh:mm:ss] ")
        + QString("删除视频 %1 个").arg(video));

    int audio = convertToAac(
        outPath.toStdWString());

    ui->textEdit->append(
        QTime::currentTime().toString("[hh:mm:ss] ")
        + QString("生成AAC %1 个").arg(audio));

    for (const auto& entry :
         std::filesystem::directory_iterator(
             srcPath.toStdWString()))
    {
        std::filesystem::remove_all(entry.path());
    }

    ui->textEdit->append(
        QTime::currentTime().toString("[hh:mm:ss] ")
        + "缓存目录已清空");

    ui->textEdit->append(
        QTime::currentTime().toString("[hh:mm:ss] ")
        + "全部任务完成");
    ui->textEdit->ensureCursorVisible();
    QMessageBox::information(this,"完成","全部任务完成");
}


void MainWindow::on_pushButton_2_clicked()
{
    QString path = QFileDialog::getExistingDirectory(
        this,
        "选择输入目录"
        );

    if (!path.isEmpty())
    {
        ui->lineEdit->setText(path);
    }
}


void MainWindow::on_pushButton_3_clicked()
{
    QString path = QFileDialog::getExistingDirectory(
        this,
        "选择输出目录"
        );

    if (!path.isEmpty())
    {
        ui->lineEdit_2->setText(path);
    }
}


void MainWindow::on_pushButton_4_clicked()
{
    QApplication::quit();
}


