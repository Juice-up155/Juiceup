 #include "process.h"

#include "extractor.h"
#include "videofilter.h"
#include "converter.h"
#include <filesystem>

namespace fs = std::filesystem;
void processFolder(const std::wstring& src,
                   const std::wstring& temp)
{
    extractM4s(src, temp);
    removeVideo(temp);
    convertToAac(temp);
    for (const auto& entry : fs::directory_iterator(src))
    {
        fs::remove_all(entry.path());
    }
    int total = extractM4s(src,temp);
    int video = removeVideo(temp);
    int audio = convertToAac(temp);
}