#pragma once
#include <string>

int convertToAac(const std::wstring& targetPath);