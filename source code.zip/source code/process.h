 #pragma once
#include <string>

void processFolder(const std::wstring& src,
                   const std::wstring& temp);