 #include "ConvertToM4a.h"

#include <filesystem>
#include <cstdlib>

namespace fs = std::filesystem;

void convertToM4a(const std::string& folderPath)
{
    if (!fs::exists(folderPath))
        return;

    for (const auto& entry : fs::directory_iterator(folderPath))
    {
        if (!entry.is_regular_file())
            continue;

        fs::path inputPath = entry.path();

        fs::path outputPath =
            inputPath.parent_path() /
            (inputPath.stem().string() + ".m4a");

        std::string command =
            "ffmpeg -y -i \"" +
            inputPath.string() +
            "\" -c:a copy \"" +
            outputPath.string() +
            "\" >nul 2>&1";

        int result = system(command.c_str());

        if (result == 0)
        {
            fs::remove(inputPath);
        }
    }
}
 