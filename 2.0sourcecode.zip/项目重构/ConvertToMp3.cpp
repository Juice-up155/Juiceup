 #include "ConvertToMp3.h"

#include <filesystem>
#include <cstdlib>

#include <iostream> //
namespace fs = std::filesystem;

void convertToMp3(const std::string& folderPath)
{
    if (!fs::exists(folderPath))
        return;

    for (const auto& entry : fs::directory_iterator(folderPath))
    {
         
        if (!entry.is_regular_file())
            continue;

        fs::path inputPath = entry.path();

        fs::path outputPath =
            inputPath.parent_path() /
            (inputPath.stem().string() + ".mp3");

        std::string command =
            "ffmpeg -y -i \"" +
            inputPath.string() +
            "\" \"" +
            outputPath.string() +
            "\" >nul 2>&1";
            
       system(command.c_str());
       int result = system(command.c_str());

if (result == 0)
{
    fs::remove(inputPath);
}
    }
}

 
