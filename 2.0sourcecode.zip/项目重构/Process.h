#ifndef PROCESS_H
#define PROCESS_H

#include <string>

void processFolder(
    const std::string& inputFolder,
    const std::string& folderPath);

#endif